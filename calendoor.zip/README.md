# Calendoor 🚪🗓️

A free, no-money, no-printer-shop photo calendar maker. Pick a photo for
each month, pick a look, print it (or save it as a PDF) — perfect for a
birthday gift when all you've got is your photos and a browser.

Everything runs **in the browser** — no server, no build step, no Python.
Photos never leave the device; they're stored locally (IndexedDB) and
only turned into pages when you hit print.

## Try it locally

Just open `index.html` in a browser — that's it. (Some browsers restrict
`file://` service workers, so if the offline-install feature doesn't kick
in locally, that's expected — it'll work once it's actually hosted.)

## Put it on GitHub Pages (automatic, via GitHub Actions)

This includes `.github/workflows/deploy.yml`, which builds and hosts the
site for you on every push to `main` — no manual "Deploy from a branch"
step needed.

1. Push this to a GitHub repo. You can push it either way:
   - the `calendoor/` folder as-is (what you already have), or
   - the whole thing zipped up as `calendoor.zip` at the repo root —
     the workflow unzips it for you automatically.
2. In the repo: **Settings → Pages → Build and deployment → Source**,
   choose **GitHub Actions** (only needs doing once).
3. Push to `main` (or run the workflow manually from the **Actions**
   tab → "Deploy Calendoor to GitHub Pages" → **Run workflow**).
4. After it finishes (~30–60 seconds), your live URL shows up in the
   Actions run summary and under **Settings → Pages**.

The old `build_calendar.py` / `build_yml.txt` files from the
PDF-generator version aren't needed anymore — this app builds the
calendar live in the browser instead.

## Turn it into an installable app with PWABuilder

1. Go to [pwabuilder.com](https://www.pwabuilder.com) and paste in your
   GitHub Pages URL.
2. PWABuilder will read `manifest.json` and `sw.js` automatically and
   score the app — it should come back green since both are already set
   up here.
3. Package it for whichever store or platform you want from there.

## Making it your own

- Swap the colors in `css/app.css` (the `:root` block at the top) and
  `css/themes.css` to reskin things.
- The icons in `/icons` are simple placeholders generated for this
  project — drop in your own `icon-192.png` / `icon-512.png` /
  `icon-maskable-512.png` any time (same file names, same folder).
- Add a new "look" by adding a `.theme-yourname` block in
  `css/themes.css` and a matching `<label class="theme-card">` entry in
  `index.html`.

## How printing works

There's no PDF library in here on purpose — the app builds a normal
printable web page and hands it to the browser's own **Print** dialog,
where "Save as PDF" is a built-in destination on every platform. That
keeps the app tiny, fast, and offline-friendly.
