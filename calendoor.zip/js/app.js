/* ===========================================================
   Calendoor — app logic
   No build step, no framework: plain JS so this can live
   straight on GitHub Pages and be wrapped by PWABuilder.
   =========================================================== */

const MONTH_NAMES = ["January","February","March","April","May","June",
                      "July","August","September","October","November","December"];

const THEMES = [
  { id: "photobooth", name: "Photo Booth" },
  { id: "clean",      name: "Clean & Bright" },
  { id: "scrapbook",  name: "Scrapbook" },
  { id: "faded",      name: "Faded Photo" },
  { id: "plants",     name: "Plants" },
  { id: "hearts",     name: "Love Hearts" },
  { id: "flowers",    name: "Flowers" },
  { id: "racing",     name: "Racing" }
];
const THEME_IDS = THEMES.map(t => t.id);

const LAYOUTS = [
  { id: "1", name: "1 photo", slots: 1 },
  { id: "2", name: "2 photos", slots: 2 },
  { id: "4", name: "4 photos", slots: 4 }
];

const STORAGE_KEY = "calendoor-state-v2";
const DB_NAME = "calendoor-db";
const STORE_NAME = "photos";

/* ---------------- tiny IndexedDB helper (photos live here, not localStorage) ---------------- */
function openDB(){
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE_NAME);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbSet(key, val){
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(val, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbDelete(key){
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbClear(){
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbGetAll(){
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const keysReq = store.getAllKeys();
    const valsReq = store.getAll();
    tx.oncomplete = () => {
      const map = new Map();
      keysReq.result.forEach((k, i) => map.set(k, valsReq.result[i]));
      resolve(map);
    };
    tx.onerror = () => reject(tx.error);
  });
}

function makeId(){
  if (crypto.randomUUID) return crypto.randomUUID();
  return "id-" + Math.random().toString(36).slice(2) + Date.now();
}

/* ---------------- state ---------------- */
function defaultCard(){
  return {
    id: makeId(),
    title: "",
    message: "",
    theme: "photobooth",
    layout: "1",
    photoIds: [null, null, null, null]
  };
}

function defaultState(){
  return {
    mode: "calendar",              // "calendar" | "cards"
    title: "",
    subtitle: "",
    year: new Date().getFullYear(),
    theme: "photobooth",
    photos: [],                                            // array of photo ids, in the order added
    months: Array.from({ length: 12 }, () => ({ photoId: null, caption: "" })),
    cards: []
  };
}

let state = defaultState();
const photoCache = new Map();   // id -> dataURL, hydrated from IndexedDB
let held = null;                // { id, source: 'tray' | 'slot', monthIndex? }

function saveState(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function loadState(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    state = Object.assign(defaultState(), parsed);
    if (!Array.isArray(state.months) || state.months.length !== 12){
      state.months = defaultState().months;
    }
    if (!Array.isArray(state.cards)) state.cards = [];
    state.cards.forEach(c => {
      if (!Array.isArray(c.photoIds)) c.photoIds = [null, null, null, null];
      while (c.photoIds.length < 4) c.photoIds.push(null);
      if (!THEME_IDS.includes(c.theme)) c.theme = "photobooth";
      if (!["1","2","4"].includes(c.layout)) c.layout = "1";
    });
    if (!THEME_IDS.includes(state.theme)) state.theme = "photobooth";
    if (state.mode !== "cards") state.mode = "calendar";
  } catch (e){
    console.warn("Couldn't read saved calendar, starting fresh.", e);
  }
}

/* Drop any references to photo ids that no longer have image data
   (e.g. localStorage survived but IndexedDB got cleared separately). */
function reconcileMissingPhotos(){
  state.photos = state.photos.filter(id => photoCache.has(id));
  state.months.forEach(m => {
    if (m.photoId && !photoCache.has(m.photoId)) m.photoId = null;
  });
  state.cards.forEach(c => {
    c.photoIds = c.photoIds.map(id => (id && photoCache.has(id)) ? id : null);
  });
}

/* ---------------- image handling ---------------- */
function resizeImageToDataUrl(file, maxDim = 1400, quality = 0.85){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error("Couldn't read that image."));
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim){
          if (width > height){ height = Math.round(height * maxDim / width); width = maxDim; }
          else { width = Math.round(width * maxDim / height); height = maxDim; }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        canvas.getContext("2d").drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

function getAverageColor(dataUrl){
  return new Promise((resolve) => {
    const img = new Image();
    img.onerror = () => resolve({ css: "#2FBFA8", text: "#fff" });
    img.onload = () => {
      const size = 24;
      const canvas = document.createElement("canvas");
      canvas.width = size; canvas.height = size;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, size, size);
      const data = ctx.getImageData(0, 0, size, size).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < data.length; i += 4){ r += data[i]; g += data[i+1]; b += data[i+2]; n++; }
      r = Math.round(r / n); g = Math.round(g / n); b = Math.round(b / n);
      const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      resolve({ css: `rgb(${r},${g},${b})`, text: luminance > 0.6 ? "#2E2A3D" : "#ffffff" });
    };
    img.src = dataUrl;
  });
}

async function storeFileAsPhoto(file){
  const dataUrl = await resizeImageToDataUrl(file);
  const id = makeId();
  await idbSet(id, dataUrl);
  photoCache.set(id, dataUrl);
  return id;
}

async function handleFiles(fileList, targetMonthIndex = null){
  const files = Array.from(fileList || []).filter(f => f.type.startsWith("image/"));
  if (!files.length) return;
  let first = true;
  for (const file of files){
    try{
      const id = await storeFileAsPhoto(file);
      state.photos.push(id);
      if (targetMonthIndex !== null && first){
        state.months[targetMonthIndex].photoId = id;
      }
    } catch (err){
      console.warn("Skipped a photo that wouldn't load:", err);
    }
    first = false;
  }
  saveState();
  render();
}

async function handleCardSlotFile(cardId, slotIndex, file){
  if (!file || !file.type.startsWith("image/")) return;
  try{
    const id = await storeFileAsPhoto(file);
    const card = state.cards.find(c => c.id === cardId);
    if (!card) return;
    card.photoIds[slotIndex] = id;
    saveState();
    render();
  } catch (err){
    console.warn("Skipped a photo that wouldn't load:", err);
  }
}

/* ---------------- rendering ---------------- */
const el = (sel) => document.querySelector(sel);

function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function themeSwatchMarkup(themeId, name, groupName, checked){
  return `
    <label class="theme-card" data-theme="${themeId}">
      <input type="radio" name="${groupName}" value="${themeId}" ${checked ? "checked" : ""}>
      <span class="theme-swatch swatch-${themeId}" aria-hidden="true"></span>
      <span class="theme-name">${name}</span>
    </label>
  `;
}

function renderThemeOptions(){
  const container = el("#themeOptions");
  container.innerHTML = THEMES.map(t => themeSwatchMarkup(t.id, t.name, "theme", state.theme === t.id)).join("");
}

function assignedPhotoIds(){
  const fromMonths = state.months.map(m => m.photoId).filter(Boolean);
  const fromCards = state.cards.flatMap(c => c.photoIds.filter(Boolean));
  return new Set([...fromMonths, ...fromCards]);
}

function renderTray(){
  const tray = el("#tray");
  const assigned = assignedPhotoIds();
  const unassigned = state.photos.filter(id => !assigned.has(id) && photoCache.has(id));

  tray.innerHTML = "";
  if (!unassigned.length){
    const p = document.createElement("p");
    p.className = "tray-empty";
    p.id = "trayEmpty";
    p.textContent = state.photos.length
      ? "All your photos are placed below. Add more any time!"
      : "No photos yet — they'll show up here first.";
    tray.appendChild(p);
    return;
  }

  for (const id of unassigned){
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "thumb" + (held && held.source === "tray" && held.id === id ? " selected" : "");
    btn.dataset.id = id;
    btn.innerHTML = `
      <img class="thumb-img" src="${photoCache.get(id)}" alt="">
      <span class="thumb-remove" data-remove="${id}" title="Remove photo" aria-label="Remove photo">×</span>
    `;
    tray.appendChild(btn);
  }
}

function renderMonths(){
  const grid = el("#monthsGrid");
  grid.innerHTML = "";
  state.months.forEach((m, i) => {
    const wrap = document.createElement("div");
    const isLiftedFromHere = held && held.source === "slot" && held.monthIndex === i;
    wrap.className = "month-slot" +
      (m.photoId ? " has-photo" : "") +
      (held && !isLiftedFromHere ? " awaiting-drop" : "") +
      (isLiftedFromHere ? " awaiting-drop" : "");
    wrap.dataset.index = String(i);
    const photoDataUrl = m.photoId ? photoCache.get(m.photoId) : null;

    wrap.innerHTML = `
      <span class="month-name">${MONTH_NAMES[i]}</span>
      <span class="month-photo-wrap">
        ${photoDataUrl
          ? `<img src="${photoDataUrl}" alt="">`
          : `<span class="placeholder" aria-hidden="true">➕</span>`}
      </span>
      ${m.photoId ? `<span class="month-remove" data-remove-month="${i}" title="Remove photo" aria-label="Remove photo">×</span>` : ""}
      <input class="caption-input" type="text" maxlength="40" placeholder="Add a note (optional)"
             value="${escapeHtml(m.caption || "")}" data-index="${i}">
    `;
    grid.appendChild(wrap);
  });
}

function renderSettings(){
  el("#titleInput").value = state.title;
  el("#subtitleInput").value = state.subtitle;
  el("#yearInput").value = state.year;
  renderThemeOptions();
}

/* ---------------- cards mode rendering ---------------- */
function cardLayoutSlots(layout){
  const l = LAYOUTS.find(x => x.id === layout);
  return l ? l.slots : 1;
}

function renderCardEditor(card, index){
  const slots = cardLayoutSlots(card.layout);
  const themeOptionsHtml = THEMES.map(t =>
    `<option value="${t.id}" ${card.theme === t.id ? "selected" : ""}>${t.name}</option>`
  ).join("");
  const layoutHtml = LAYOUTS.map(l => `
    <label class="layout-option" data-layout="${l.id}">
      <input type="radio" name="layout-${card.id}" value="${l.id}" ${card.layout === l.id ? "checked" : ""}>
      ${l.name}
    </label>
  `).join("");

  let slotsHtml = "";
  for (let s = 0; s < slots; s++){
    const photoId = card.photoIds[s];
    const dataUrl = photoId ? photoCache.get(photoId) : null;
    slotsHtml += `
      <div class="card-photo-slot" data-card="${card.id}" data-slot="${s}">
        ${dataUrl
          ? `<img src="${dataUrl}" alt=""><span class="slot-remove" data-remove-slot="${s}" data-remove-card="${card.id}" title="Remove photo" aria-label="Remove photo">×</span>`
          : `<span class="placeholder" aria-hidden="true">📷</span>`}
      </div>
    `;
  }

  const wrap = document.createElement("div");
  wrap.className = "card-editor";
  wrap.dataset.cardId = card.id;
  wrap.innerHTML = `
    <div class="card-editor-head">
      <h3>Card ${index + 1}</h3>
      <button type="button" class="card-remove-btn" data-remove-card-full="${card.id}" title="Delete card" aria-label="Delete card">×</button>
    </div>
    <div class="card-fields">
      <label class="field">
        <span>Title <em>(optional)</em></span>
        <input type="text" maxlength="60" class="card-title-input" data-card="${card.id}" value="${escapeHtml(card.title)}" placeholder="Happy Birthday!">
      </label>
      <label class="field">
        <span>Look</span>
        <select class="card-theme-select" data-card="${card.id}">${themeOptionsHtml}</select>
      </label>
      <label class="field field-full">
        <span>Message <em>(optional)</em></span>
        <textarea maxlength="240" class="card-message-input" data-card="${card.id}" placeholder="Write your message here...">${escapeHtml(card.message)}</textarea>
      </label>
    </div>
    <div class="layout-picker" data-card="${card.id}">${layoutHtml}</div>
    <div class="card-photo-slots" data-layout="${card.layout}">${slotsHtml}</div>
  `;
  return wrap;
}

function renderCards(){
  const list = el("#cardsList");
  const empty = el("#cardsEmpty");
  list.innerHTML = "";
  empty.hidden = state.cards.length > 0;
  state.cards.forEach((card, i) => list.appendChild(renderCardEditor(card, i)));
}

function renderPickedUpMsg(){
  el("#pickedUpMsg").hidden = !held || state.mode !== "calendar";
}

function renderModeUI(){
  const isCalendar = state.mode === "calendar";
  el("#calendarMode").hidden = !isCalendar;
  el("#cardsMode").hidden = isCalendar;
  el("#tabCalendar").classList.toggle("is-active", isCalendar);
  el("#tabCalendar").setAttribute("aria-pressed", String(isCalendar));
  el("#tabCards").classList.toggle("is-active", !isCalendar);
  el("#tabCards").setAttribute("aria-pressed", String(!isCalendar));
  el("#printBtn").textContent = isCalendar ? "🖨️ Print / Save as PDF" : "🖨️ Print cards / Save as PDF";
}

function render(){
  renderModeUI();
  renderTray();
  renderMonths();
  renderCards();
  renderPickedUpMsg();
}

/* ---------------- placement logic (tap to pick up, tap to drop) ---------------- */
function placeHeldOnto(targetIndex){
  if (!held) return;

  if (held.source === "slot" && held.monthIndex === targetIndex){
    held = null; // tapped the same slot again: put it back down, nothing changes
    render();
    return;
  }

  const occupantId = state.months[targetIndex].photoId;

  if (held.source === "slot"){
    // swap the two months' photos (or move, if target was empty)
    state.months[held.monthIndex].photoId = occupantId || null;
    state.months[targetIndex].photoId = held.id;
  } else {
    // coming from the tray: target's old occupant (if any) simply becomes unassigned again
    state.months[targetIndex].photoId = held.id;
  }

  held = null;
  saveState();
  render();
}

/* ---------------- calendar grid + printable pages ---------------- */
function buildMonthGridHtml(year, monthIndex){
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const startCol = (new Date(year, monthIndex, 1).getDay() + 6) % 7; // Monday = 0
  const cells = Array(startCol).fill(null)
    .concat(Array.from({ length: daysInMonth }, (_, i) => i + 1));
  while (cells.length % 7 !== 0) cells.push(null);

  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === monthIndex;

  let rows = "";
  for (let i = 0; i < cells.length; i += 7){
    const week = cells.slice(i, i + 7);
    rows += "<tr>" + week.map(d => {
      if (d === null) return "<td></td>";
      const isToday = isCurrentMonth && d === today.getDate();
      return isToday ? `<td class="today"><span>${d}</span></td>` : `<td>${d}</td>`;
    }).join("") + "</tr>";
  }

  return `<table class="cal-grid">
    <thead><tr>${["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map(d => `<th>${d}</th>`).join("")}</tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

const BORDER_THEMES = new Set(["plants", "hearts", "flowers", "racing"]);

async function buildPrintableCalendar(root){
  for (let i = 0; i < 12; i++){
    const m = state.months[i];
    const photoDataUrl = m.photoId ? photoCache.get(m.photoId) : null;
    const hasDecoStrip = BORDER_THEMES.has(state.theme);

    const page = document.createElement("section");
    page.className = `cal-page theme-${state.theme}`;
    page.innerHTML = `
      ${state.theme === "faded" && photoDataUrl ? `<img class="faded-photo" src="${photoDataUrl}" alt="">` : ""}
      ${hasDecoStrip ? `<div class="deco-strip deco-top"></div>` : ""}
      <header class="cal-page-head">
        <h2 class="cal-title">${escapeHtml(state.title || "Our Calendar")}</h2>
        ${state.subtitle ? `<p class="cal-subtitle">${escapeHtml(state.subtitle)}</p>` : ""}
      </header>
      <div class="cal-photo-wrap">
        ${photoDataUrl ? `<img class="cal-photo" src="${photoDataUrl}" alt="">` : ""}
      </div>
      ${m.caption ? `<p class="cal-caption">${escapeHtml(m.caption)}</p>` : ""}
      <h3 class="cal-month">${MONTH_NAMES[i]} ${state.year}</h3>
      ${buildMonthGridHtml(state.year, i)}
      ${hasDecoStrip ? `<div class="deco-strip deco-bottom"></div>` : ""}
    `;

    if (state.theme === "clean" && photoDataUrl){
      const { css, text } = await getAverageColor(photoDataUrl);
      page.style.setProperty("--accent", css);
      page.style.setProperty("--accent-text", text);
    }

    root.appendChild(page);
  }
}

function buildPrintableCards(root){
  const cards = state.cards;
  for (let i = 0; i < cards.length; i += 2){
    const pair = cards.slice(i, i + 2);
    const page = document.createElement("section");
    page.className = "cards-page";

    pair.forEach(card => {
      const slots = cardLayoutSlots(card.layout);
      const photos = card.photoIds.slice(0, slots);
      const firstPhoto = photos.find(id => id && photoCache.has(id));

      const cardEl = document.createElement("div");
      cardEl.className = `card-print theme-${card.theme}`;

      if (card.theme === "faded" && firstPhoto){
        const img = document.createElement("img");
        img.className = "faded-photo";
        img.alt = "";
        img.src = photoCache.get(firstPhoto);
        cardEl.appendChild(img);
      }
      if (card.title){
        const h3 = document.createElement("h3");
        h3.className = "card-print-title";
        h3.textContent = card.title;
        cardEl.appendChild(h3);
      }
      if (card.theme !== "faded"){
        const grid = document.createElement("div");
        grid.className = "card-photo-grid";
        grid.dataset.layout = card.layout;
        photos.forEach(id => {
          if (!id || !photoCache.has(id)) return;
          const img = document.createElement("img");
          img.src = photoCache.get(id);
          img.alt = "";
          grid.appendChild(img);
        });
        cardEl.appendChild(grid);
      }
      if (card.message){
        const p = document.createElement("p");
        p.className = "card-print-message";
        p.textContent = card.message;
        cardEl.appendChild(p);
      }
      page.appendChild(cardEl);
    });

    root.appendChild(page);
  }
}

async function buildPrintable(){
  const root = el("#printRoot");
  root.innerHTML = "";
  if (state.mode === "calendar"){
    await buildPrintableCalendar(root);
  } else {
    buildPrintableCards(root);
  }
}

async function handlePrint(){
  if (state.mode === "calendar"){
    const missing = state.months.filter(m => !m.photoId).length;
    if (missing > 0){
      const ok = confirm(`${missing} month${missing === 1 ? "" : "s"} don't have a photo yet. Print anyway?`);
      if (!ok) return;
    }
  } else {
    if (!state.cards.length){
      alert("Add at least one card first!");
      return;
    }
  }
  await buildPrintable();
  window.print();
}

/* ---------------- start over ---------------- */
async function startOver(){
  const ok = confirm("This clears your title, photos, cards, and notes on this device. Are you sure?");
  if (!ok) return;
  await idbClear();
  localStorage.removeItem(STORAGE_KEY);
  photoCache.clear();
  state = defaultState();
  held = null;
  renderSettings();
  render();
}

/* ---------------- wiring ---------------- */
function switchMode(mode){
  state.mode = mode === "cards" ? "cards" : "calendar";
  held = null;
  saveState();
  render();
}

function initCardEvents(){
  el("#addCardBtn").addEventListener("click", () => {
    state.cards.push(defaultCard());
    saveState();
    render();
  });

  const list = el("#cardsList");

  list.addEventListener("click", (e) => {
    const delCard = e.target.closest("[data-remove-card-full]");
    if (delCard){
      const id = delCard.dataset.removeCardFull;
      state.cards = state.cards.filter(c => c.id !== id);
      saveState();
      render();
      return;
    }

    const delSlot = e.target.closest("[data-remove-slot]");
    if (delSlot){
      const cardId = delSlot.dataset.removeCard;
      const slotIndex = parseInt(delSlot.dataset.removeSlot, 10);
      const card = state.cards.find(c => c.id === cardId);
      if (card){ card.photoIds[slotIndex] = null; saveState(); render(); }
      return;
    }

    const slot = e.target.closest(".card-photo-slot");
    if (slot && !slot.querySelector("img")){
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.hidden = true;
      input.addEventListener("change", (ev) => {
        handleCardSlotFile(slot.dataset.card, parseInt(slot.dataset.slot, 10), ev.target.files[0]);
      });
      document.body.appendChild(input);
      input.click();
      input.addEventListener("change", () => input.remove());
    }
  });

  list.addEventListener("input", (e) => {
    const cardId = e.target.dataset.card;
    if (!cardId) return;
    const card = state.cards.find(c => c.id === cardId);
    if (!card) return;
    if (e.target.classList.contains("card-title-input")) card.title = e.target.value;
    if (e.target.classList.contains("card-message-input")) card.message = e.target.value;
    saveState();
  });

  list.addEventListener("change", (e) => {
    const cardId = e.target.dataset.card;
    if (cardId && e.target.classList.contains("card-theme-select")){
      const card = state.cards.find(c => c.id === cardId);
      if (card){ card.theme = e.target.value; saveState(); }
      return;
    }
    if (e.target.name && e.target.name.startsWith("layout-")){
      const id = e.target.name.replace("layout-", "");
      const card = state.cards.find(c => c.id === id);
      if (card){ card.layout = e.target.value; saveState(); render(); }
    }
  });
}

function initEvents(){
  el("#titleInput").addEventListener("input", (e) => { state.title = e.target.value; saveState(); });
  el("#subtitleInput").addEventListener("input", (e) => { state.subtitle = e.target.value; saveState(); });
  el("#yearInput").addEventListener("input", (e) => {
    const y = parseInt(e.target.value, 10);
    if (!isNaN(y)) { state.year = y; saveState(); }
  });
  el("#themeOptions").addEventListener("change", (e) => {
    if (e.target.name === "theme"){ state.theme = e.target.value; saveState(); }
  });

  el("#tabCalendar").addEventListener("click", () => switchMode("calendar"));
  el("#tabCards").addEventListener("click", () => switchMode("cards"));

  el("#fileInput").addEventListener("change", (e) => {
    handleFiles(e.target.files, null);
    e.target.value = "";
  });

  el("#tray").addEventListener("click", (e) => {
    const removeBtn = e.target.closest("[data-remove]");
    if (removeBtn){
      const id = removeBtn.dataset.remove;
      state.photos = state.photos.filter(pid => pid !== id);
      state.months.forEach(m => { if (m.photoId === id) m.photoId = null; });
      state.cards.forEach(c => { c.photoIds = c.photoIds.map(pid => pid === id ? null : pid); });
      photoCache.delete(id);
      idbDelete(id);
      if (held && held.id === id) held = null;
      saveState();
      render();
      return;
    }
    const thumb = e.target.closest(".thumb");
    if (thumb){
      const id = thumb.dataset.id;
      if (held && held.source === "tray" && held.id === id){
        held = null; // tapped it again: put it back down
      } else {
        held = { id, source: "tray" };
      }
      render();
    }
  });

  el("#monthsGrid").addEventListener("click", (e) => {
    if (e.target.tagName === "INPUT") return; // let the caption field just be a text field

    const removeBtn = e.target.closest("[data-remove-month]");
    if (removeBtn){
      const i = parseInt(removeBtn.dataset.removeMonth, 10);
      if (held && held.source === "slot" && held.monthIndex === i) held = null;
      state.months[i].photoId = null;
      saveState();
      render();
      return;
    }

    const slot = e.target.closest(".month-slot");
    if (!slot) return;
    const i = parseInt(slot.dataset.index, 10);

    if (!held){
      if (state.months[i].photoId){
        held = { id: state.months[i].photoId, source: "slot", monthIndex: i };
        render();
      } else {
        // empty slot, nothing picked up yet: shortcut straight to the photo picker
        el("#slotFileInput").dataset.targetIndex = String(i);
        el("#slotFileInput").click();
      }
      return;
    }

    placeHeldOnto(i);
  });

  el("#monthsGrid").addEventListener("input", (e) => {
    if (e.target.classList.contains("caption-input")){
      const i = parseInt(e.target.dataset.index, 10);
      state.months[i].caption = e.target.value;
      saveState();
    }
  });

  el("#printBtn").addEventListener("click", handlePrint);
  el("#startOverBtn").addEventListener("click", startOver);

  initCardEvents();
}

function addHiddenSlotFileInput(){
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "image/*";
  input.id = "slotFileInput";
  input.hidden = true;
  input.addEventListener("change", (e) => {
    const idx = parseInt(input.dataset.targetIndex, 10);
    handleFiles(e.target.files, isNaN(idx) ? null : idx);
    e.target.value = "";
  });
  document.body.appendChild(input);
}

/* ---------------- boot ---------------- */
async function init(){
  loadState();
  try{
    const map = await idbGetAll();
    for (const [id, dataUrl] of map) photoCache.set(id, dataUrl);
  } catch (e){
    console.warn("Photo storage isn't available in this browser context.", e);
  }
  reconcileMissingPhotos();
  addHiddenSlotFileInput();
  initEvents();
  renderSettings();
  render();

  if ("serviceWorker" in navigator){
    navigator.serviceWorker.register("sw.js").catch(() => { /* offline support is a bonus, not required */ });
  }
}

init();
